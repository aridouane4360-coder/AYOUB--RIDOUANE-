<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${empty student ? 'Add Student' : 'Edit Student'}</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<div class="container">
    <header>
        <h1>${empty student ? '➕ Add Student' : '✏️ Edit Student'}</h1>
        <a href="${pageContext.request.contextPath}/students/" class="btn btn-secondary">← Back to List</a>
    </header>

    <div class="form-card">
        <c:choose>
            <c:when test="${empty student}">
                <form action="${pageContext.request.contextPath}/students/create" method="post">
            </c:when>
            <c:otherwise>
                <form action="${pageContext.request.contextPath}/students/update" method="post">
                <input type="hidden" name="id" value="${student.id}">
            </c:otherwise>
        </c:choose>

            <div class="form-group">
                <label for="firstName">First Name</label>
                <input type="text" id="firstName" name="firstName"
                       value="${student.firstName}" required placeholder="e.g. Ahmed">
            </div>

            <div class="form-group">
                <label for="lastName">Last Name</label>
                <input type="text" id="lastName" name="lastName"
                       value="${student.lastName}" required placeholder="e.g. Benali">
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email"
                       value="${student.email}" required placeholder="e.g. ahmed@example.com">
            </div>

            <div class="form-group">
                <label for="age">Age</label>
                <input type="number" id="age" name="age"
                       value="${student.age}" required min="1" max="120" placeholder="e.g. 22">
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    ${empty student ? '💾 Save Student' : '💾 Update Student'}
                </button>
                <a href="${pageContext.request.contextPath}/students/" class="btn btn-secondary">Cancel</a>
            </div>

        </form>
    </div>
</div>

</body>
</html>
