package com.example.servlet;

import com.example.dao.StudentDAO;
import com.example.dao.StudentDAOImpl;
import com.example.model.Student;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/students/*")
public class StudentServlet extends HttpServlet {

    private final StudentDAO dao = new StudentDAOImpl();

    // ── LIST ──────────────────────────────────────────────────────────────────
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String pathInfo = req.getPathInfo(); // e.g. null, "/new", "/edit", "/delete"

        if (pathInfo == null || pathInfo.equals("/")) {
            // LIST all students
            List<Student> students = dao.getAllStudents();
            req.setAttribute("students", students);
            req.getRequestDispatcher("/WEB-INF/views/list.jsp").forward(req, resp);

        } else if (pathInfo.equals("/new")) {
            // Show ADD form
            req.getRequestDispatcher("/WEB-INF/views/form.jsp").forward(req, resp);

        } else if (pathInfo.equals("/edit")) {
            // Show EDIT form pre-filled
            int id = Integer.parseInt(req.getParameter("id"));
            Student student = dao.getStudentById(id);
            req.setAttribute("student", student);
            req.getRequestDispatcher("/WEB-INF/views/form.jsp").forward(req, resp);

        } else if (pathInfo.equals("/delete")) {
            // DELETE student
            int id = Integer.parseInt(req.getParameter("id"));
            dao.deleteStudent(id);
            resp.sendRedirect(req.getContextPath() + "/students/");
        }
    }

    // ── CREATE / UPDATE ───────────────────────────────────────────────────────
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String pathInfo = req.getPathInfo();

        String firstName = req.getParameter("firstName").trim();
        String lastName  = req.getParameter("lastName").trim();
        String email     = req.getParameter("email").trim();
        int    age       = Integer.parseInt(req.getParameter("age").trim());

        if (pathInfo.equals("/create")) {
            dao.addStudent(new Student(firstName, lastName, email, age));

        } else if (pathInfo.equals("/update")) {
            int id = Integer.parseInt(req.getParameter("id"));
            dao.updateStudent(new Student(id, firstName, lastName, email, age));
        }

        resp.sendRedirect(req.getContextPath() + "/students/");
    }
}
