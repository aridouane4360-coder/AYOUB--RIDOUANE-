<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<div class="container">
    <header>
        <h1>🎓 Student Management</h1>
        <a href="${pageContext.request.contextPath}/students/new" class="btn btn-primary">+ Add Student</a>
    </header>

    <c:choose>
        <c:when test="${empty students}">
            <div class="empty-state">
                <p>No students yet. Add your first student!</p>
            </div>
        </c:when>
        <c:otherwise>
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Age</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="s" items="${students}">
                        <tr>
                            <td>${s.id}</td>
                            <td>${s.firstName}</td>
                            <td>${s.lastName}</td>
                            <td>${s.email}</td>
                            <td>${s.age}</td>
                            <td class="actions">
                                <a href="${pageContext.request.contextPath}/students/edit?id=${s.id}"
                                   class="btn btn-edit">✏️ Edit</a>
                                <a href="${pageContext.request.contextPath}/students/delete?id=${s.id}"
                                   class="btn btn-delete"
                                   onclick="return confirm('Delete ${s.firstName} ${s.lastName}?')">🗑️ Delete</a>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
            <p class="count">Total: <strong>${students.size()}</strong> student(s)</p>
        </c:otherwise>
    </c:choose>
</div>

</body>
</html>
