package com.example.dao;

import com.example.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements StudentDAO {

    // ── READ ALL ──────────────────────────────────────────────────────────────
    @Override
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students ORDER BY id DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                students.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching students", e);
        }
        return students;
    }

    // ── READ ONE ──────────────────────────────────────────────────────────────
    @Override
    public Student getStudentById(int id) {
        String sql = "SELECT * FROM students WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching student id=" + id, e);
        }
        return null;
    }

    // ── CREATE ────────────────────────────────────────────────────────────────
    @Override
    public void addStudent(Student s) {
        String sql = "INSERT INTO students (first_name, last_name, email, age) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, s.getFirstName());
            ps.setString(2, s.getLastName());
            ps.setString(3, s.getEmail());
            ps.setInt(4, s.getAge());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Error adding student", e);
        }
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────
    @Override
    public void updateStudent(Student s) {
        String sql = "UPDATE students SET first_name=?, last_name=?, email=?, age=? WHERE id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, s.getFirstName());
            ps.setString(2, s.getLastName());
            ps.setString(3, s.getEmail());
            ps.setInt(4, s.getAge());
            ps.setInt(5, s.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Error updating student id=" + s.getId(), e);
        }
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    @Override
    public void deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Error deleting student id=" + id, e);
        }
    }

    // ── HELPER ────────────────────────────────────────────────────────────────
    private Student mapRow(ResultSet rs) throws SQLException {
        return new Student(
            rs.getInt("id"),
            rs.getString("first_name"),
            rs.getString("last_name"),
            rs.getString("email"),
            rs.getInt("age")
        );
    }
}
