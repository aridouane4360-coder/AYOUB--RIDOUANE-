package com.example.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    // These values are read from environment variables injected by Docker
    private static final String URL      = System.getenv().getOrDefault("DB_URL",      "jdbc:mysql://db:3306/student_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
    private static final String USER     = System.getenv().getOrDefault("DB_USER",     "root");
    private static final String PASSWORD = System.getenv().getOrDefault("DB_PASSWORD", "root");

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL driver not found", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
